// const Random = require("mockjs").Random;
//
// const paperInfoVO = {
//   data: {
//     abst: "@sentence",
//     "articleCtiationCount|0-1000": 1,
//     "authors|3-6": [
//       {
//         affiliations: "@sentence",
//         "id|0-1000": 0,
//         name: "@name"
//       }
//     ],
//     keywords: "AsdasdasdAasdasdNji jkLasdNASAHaha",
//     pdf_link: "@url",
//     publicationTitle: "@sentence",
//     referenceCount: 0,
//     title: "@sentence",
//     year: 2016
//   },
//   message: "ok"
// };
//
// module.exports = {
//   displayPaper: ["/paper", "get", paperInfoVO]
// };
