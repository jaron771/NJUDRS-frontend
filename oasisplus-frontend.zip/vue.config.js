module.exports = {
  configureWebpack: {
    devServer: {}
  }
};
